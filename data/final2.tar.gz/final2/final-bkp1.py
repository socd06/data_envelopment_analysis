import pandas as pd
import locale
locale.setlocale( locale.LC_ALL, 'en_US.UTF-8' ) 
import os

#######################################################################################################
# Parameters of the model:
# N: How many WWTP, each WWTP selected is going to be the k-th
# M: How many inputs per k-th WWTP
# S: How many desirable outputs per k-th WWTP
# L: How many undesirable outputs per k-th WWTP
#######################################################################################################
N = 7
M = 1
S = 3
L = 1

DATAFILE='amb.csv'
PROMEDIOS='promedios.csv'

def main():
    x = []
    y = []
    b = []
    rTol = []
    sTol = []
    tTol = []

    setTable( x , y, b )
    setTol( x, y, b, rTol, sTol, tTol)
    #setTol( x, rTol)

#    for x   
#        -1, 0, 1 * rik
#        for y
#            -1, 0, 1 * sik
#            for b
#            -1, 0, 1 * tik

    fname = "del.txt"
    writeFile(x, y, b, fname)
    #runFile()


#######################################################################################################
def writeFile(x, y, b, FILE):
    f = open(FILE, "w")

    f.write("var t >= 0;\n")
    f.write("var lam1 >= 0;\n")
    f.write("var lam2 >= 0;\n")
    f.write("var lam3 >= 0;\n")
    f.write("var lam4 >= 0;\n")
    f.write("var lam5 >= 0;\n")
    f.write("var lam6 >= 0;\n")
    f.write("var lam7 >= 0;\n")

    conta = 1
    # x1 loop
    print "c{0:d}: ".format(conta),
    for k in range (N):
        if ( k < N-1):
            print "lam{0:d}*{1:.2f} +".format(k + 1,x[k][0]),
        else:
            print "lam{0:d}*{1:.2f}".format(k + 1,x[k][0]),
    conta = conta + 1
    print " "

    # y1 loop
    print "c{0:d}: ".format(conta),
    for k in range (N):
        if ( k < N-1):
            print "lam{0:d}*{1:.2f} +".format(k + 1,y[k][0]),
        else:
            print "lam{0:d}*{1:.2f}".format(k + 1,y[k][0]),
    conta = conta + 1
    print " "

    # y2 loop
    print "c{0:d}: ".format(conta),
    for k in range (N):
        if ( k < N-1):
            print "lam{0:d}*{1:.2f} +".format(k + 1,y[k][1]),
        else:
            print "lam{0:d}*{1:.2f}".format(k + 1,y[k][1]),
    conta = conta + 1
    print " "

    # y3 loop
    print "c{0:d}: ".format(conta),
    for k in range (N):
        if ( k < N-1):
            print "lam{0:d}*{1:.2f} +".format(k + 1,y[k][2]),
        else:
            print "lam{0:d}*{1:.2f}".format(k + 1,y[k][2]),
    conta = conta + 1
    print " "

    # b1 loop
    print "c{0:d}: ".format(conta),
    for k in range (N):
        if ( k < N-1):
            print "lam{0:d}*{1:.2f} +".format(k + 1,b[k][0]),
        else:
            print "lam{0:d}*{1:.2f}".format(k + 1,b[k][0]),
    conta = conta + 1
    print " "

    f.close()

def runFile():
    temp="del"
    osCommand = "glpsol --math "+temp+".ampl >"+ temp+".log 2>&1"
    os.system(osCommand)

def setTable ( r = [], s = [], t = [] ):
    initializeVars(r, s, t)
    df = pd.read_csv(DATAFILE)
    #print float(df.X1[1])

#    for j in range (M):
    # Set M0 values
    for i in range (N):
        r[i][0] = float(df.X1[i])

    # Set S0 values
    for i in range (N):
        s[i][0] = float(df.Y1[i])
    # Set S1 values
    for i in range (N):
        s[i][1] = float(df.Y2[i])
    # Set S2 values
    for i in range (N):
        s[i][2] = float(df.Y3[i])

    # Set L0 value
    for i in range (N):
        t[i][0] = float(df.B1[i])

def setTol ( r = [], s = [], t = [], Rtol = [], Stol = [], Ttol = [] ):
    initializeVars(r, s, t)
    initializeVars(Rtol, Stol, Ttol)

    df = pd.read_csv(PROMEDIOS)
    print float(df.X1[0])

#    for j in range (M):
    # Set M0 values
    for i in range (N):
        #Rtol[i][0] = float(df.X1[i])
        Rtol[i][0] = abs(float(df.X1[i]) - float(r[i][0]))/float(df.X1[i])

#    print Rtol

    # Set S0 values
    for i in range (N):
        Stol[i][0] = abs(float(df.Y1[i]) - float(s[i][0]))/float(df.Y1[i])
    # Set S1 values
    for i in range (N):
        Stol[i][1] = abs(float(df.Y2[i]) - float(s[i][1]))/float(df.Y2[i])
    # Set S2 values
    for i in range (N):
        Stol[i][2] = abs(float(df.Y3[i]) - float(s[i][2]))/float(df.Y3[i])

#    print Stol
    # Set L0 value
    for i in range (N):
        Ttol[i][0] = abs(float(df.B1[i]) - float(t[i][0]))/float(df.B1[i])
#    print Ttol

def initializeVars( r = [], s = [], t = [] ):
    for i in range (N):
        dummy1 = []
        dummy2 = []
        dummy3 = []
        for j in range (M):
            dummy1.append(0)
        r.append(dummy1)

        for j in range(S):    
            dummy2.append(0)
        s.append(dummy2)

        for j in range(L):
            dummy3.append(0)
        t.append(dummy3)

#######################################################################################################

main()

