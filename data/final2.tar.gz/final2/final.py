import pandas as pd
import locale
locale.setlocale( locale.LC_ALL, 'en_US.UTF-8' ) 
import os

#######################################################################################################
# Parameters of the model:
# N: How many WWTP, each WWTP selected is going to be the k-th
# M: How many inputs per k-th WWTP
# S: How many desirable outputs per k-th WWTP
# L: How many undesirable outputs per k-th WWTP
#######################################################################################################
N = 7
M = 1
S = 3
L = 1

DATAFILE='amb.csv'
PROMEDIOS='promedios.csv'

def main():
    x = []
    y = []
    b = []
    rTol = []
    sTol = []
    tTol = []

    setTable( x , y, b )
    setTol( x, y, b, rTol, sTol, tTol)


# 1. mejor escenario todos: x0(1-rik0), y0(1+sik0), b0(1-tlk0)
# 2. normal
# 3. peor escenario todos: x0(1+rik0), y0(1-sik0), b0(1+tlk0)
# Hay 6 ciclos, los primeros 3 es para mover la tolerancia en loa derecha del <=
# los otros 3 es para mover la tolerancia en los elemntos de la izquierda <=

    for i in range (1):
        for xi0 in range (-1, 2, 1):
            for yi0 in range (-1, 2, 1):
                for zi0 in range (-1, 2, 1):
                    for xi in range (-1, 2, 1):
                        for yi in range (-1, 2, 1):
                            for zi in range (-1, 2, 1):
                                fname = str(i+1)+"-t"+str(xi0)+str(yi0)+str(zi0)+"-v"+str(xi)+str(yi)+str(zi)+".ampl"
#                                writeFile(i, fname, x, y, b, rTol, sTol, tTol, modR, modS, modT, caseX, caseY, caseB)
                                writeFile(i, fname, x, y, b, rTol, sTol, tTol, xi, yi, zi, xi0, yi0, zi0)
                                runFile(fname)
                                #print fname


#######################################################################################################
def writeFile(IND, FILE, x, y, b, Rtol, Stol, Ttol, Modr, Mods, Modt, CX, CY, CB ):
    f = open(FILE, "w")

    f.write("var t >= 0;\n")
    f.write("var lam1 >= 0;\n")
    f.write("var lam2 >= 0;\n")
    f.write("var lam3 >= 0;\n")
    f.write("var lam4 >= 0;\n")
    f.write("var lam5 >= 0;\n")
    f.write("var lam6 >= 0;\n")
    f.write("var lam7 >= 0;\n")
    f.write("minimize obj: t;\n")

    conta = 1
    # x1 loop
    f.write("c%i: " % (conta) )
    for k in range (N):
        if ( k < N-1):
            f.write("lam%i*%1.2f + " % (k+1, x[k][0] * (1 + Modr * Rtol[k][0]) ) ) 
        else:
            f.write("lam%i*%1.2f <= %1.2f*t;" % (k+1, x[k][0] * (1 + Modr * Rtol[k][0]), x[IND][0]* (1 + CX * Rtol[IND][0]) ) )
    conta = conta + 1
    f.write("\n")

    # y1 loop
    f.write("c%i: " % (conta) )
    for k in range (N):
        if ( k < N-1):
            f.write("lam%i*%1.2f + " % (k+1, y[k][0] * (1 + Mods * Stol[k][0]) ) ) 
        else:
            f.write("lam%i*%1.2f >= %1.2f;" % (k+1, y[k][0] * (1 + Mods * Stol[k][0]), y[IND][0]* (1 + CY * Stol[IND][0]) ) )
    conta = conta + 1
    f.write("\n")

    # y2 loop
    f.write("c%i: " % (conta) )
    for k in range (N):
        if ( k < N-1):
            f.write("lam%i*%1.2f + " % (k+1, y[k][1] * (1 + Mods * Stol[k][1]) ) ) 
        else:
            f.write("lam%i*%1.2f >= %1.2f;" % (k+1, y[k][1] * (1 + Mods * Stol[k][1]), y[IND][1]* (1 + CY * Stol[IND][1]) ) )
    conta = conta + 1
    f.write("\n")

    # y3 loop
    f.write("c%i: " % (conta) )
    for k in range (N):
        if ( k < N-1):
            f.write("lam%i*%1.2f + " % (k+1, y[k][2] * (1 + Mods * Stol[k][2]) ) ) 
        else:
            f.write("lam%i*%1.2f >= %1.2f;" % (k+1, y[k][2] * (1 + Mods * Stol[k][2]), y[IND][2]* (1 + CY * Stol[IND][2]) ) )
    conta = conta + 1
    f.write("\n")

    # b1 loop
    f.write("c%i: " % (conta) )
    for k in range (N):
        if ( k < N-1):
            f.write("lam%i*%1.2f + " % (k+1, b[k][0] * (1 + Modt * Ttol[k][0]) ) ) 
        else:
            f.write("lam%i*%1.2f = %1.2f;" % (k+1, b[k][0] * (1 + Modt * Ttol[k][0]), b[IND][0]* (1 + CB * Ttol[IND][0]) ) )
    conta = conta + 1
    f.write("\n")

    f.write("c%i: lam1 + lam2 + lam3 + lam4 + lam5 + lam6 + lam7 = 1;\n" % (conta) )

    f.write("solve;\n")
    f.write("display t;\n")
    f.write("end;\n")
    f.close()

def runFile(FILE):
    osCommand = "glpsol --math " + FILE + " > " + FILE + ".log 2>&1"
    print osCommand
    os.system(osCommand)
    osCommand = "mv *.log ./LOGS"
    os.system(osCommand)
    osCommand = "mv *.ampl ./AMPLS"
    os.system(osCommand)

def setTable ( r = [], s = [], t = [] ):
    initializeVars(r, s, t)
    df = pd.read_csv(DATAFILE)
    #print float(df.X1[1])

#    for j in range (M):
    # Set M0 values
    for i in range (N):
        r[i][0] = float(df.X1[i])

    # Set S0 values
    for i in range (N):
        s[i][0] = float(df.Y1[i])
    # Set S1 values
    for i in range (N):
        s[i][1] = float(df.Y2[i])
    # Set S2 values
    for i in range (N):
        s[i][2] = float(df.Y3[i])

    # Set L0 value
    for i in range (N):
        t[i][0] = float(df.B1[i])

def setTol ( r = [], s = [], t = [], Rtol = [], Stol = [], Ttol = [] ):
    initializeVars(r, s, t)
    initializeVars(Rtol, Stol, Ttol)

    df = pd.read_csv(PROMEDIOS)
    #print float(df.X1[0])

#    for j in range (M):
    # Set M0 values
    for i in range (N):
        #Rtol[i][0] = float(df.X1[i])
        Rtol[i][0] = abs(float(df.X1[i]) - float(r[i][0]))/float(df.X1[i])

#    print Rtol

    # Set S0 values
    for i in range (N):
        Stol[i][0] = abs(float(df.Y1[i]) - float(s[i][0]))/float(df.Y1[i])
    # Set S1 values
    for i in range (N):
        Stol[i][1] = abs(float(df.Y2[i]) - float(s[i][1]))/float(df.Y2[i])
    # Set S2 values
    for i in range (N):
        Stol[i][2] = abs(float(df.Y3[i]) - float(s[i][2]))/float(df.Y3[i])

#    print Stol
    # Set L0 value
    for i in range (N):
        Ttol[i][0] = abs(float(df.B1[i]) - float(t[i][0]))/float(df.B1[i])
#    print Ttol

def initializeVars( r = [], s = [], t = [] ):
    for i in range (N):
        dummy1 = []
        dummy2 = []
        dummy3 = []
        for j in range (M):
            dummy1.append(0)
        r.append(dummy1)

        for j in range(S):    
            dummy2.append(0)
        s.append(dummy2)

        for j in range(L):
            dummy3.append(0)
        t.append(dummy3)

#######################################################################################################

main()

